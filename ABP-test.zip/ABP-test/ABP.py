from copy import deepcopy

class node:
    def __init__(self, data):
        self.data = data
        self.children = []

    def is_leaf(self):
        return True if len(self.children) == 0 else False

    def add(self, nodes):
        self.children.append(nodes)
        return None

class tree:
    def __init__(self, root_data, max_min_dict, edges):
        self.root = node(root_data)
        self.max_min_dict = max_min_dict
        self.count = 0
        self.edges = edges
        part_of_edges = self.add_root_children(deepcopy(edges))
        self.add_nodes(self.root, part_of_edges)

    def add_root_children(self, edges):
        used = []
        for i in edges:
            if i[0] == self.root.data:
                self.root.add(node(i[-1]))
                used.append(i)
        for i in used:
            edges.remove(i)
        return edges

    def add_nodes(self, nodes, edges):
        if nodes.is_leaf():
            return None
        used = []
        for i in nodes.children:
            for j in edges:
                if j[0] == i.data:
                    i.add(node(j[-1]))
                    used.append(j)
            for k in used:
                edges.remove(k)
            used = []
            self.add_nodes(i, edges)

    def alpha_beta(self, current_node, alpha, beta):
        if current_node == self.root:
            alpha = float("-inf")
            beta = float("inf")
        if current_node.is_leaf():
            self.count += 1
            return int(current_node.data)
        value = current_node.data
        if self.max_min_dict[value] == "MAX":
            for child in current_node.children:
                alpha = max(alpha, self.alpha_beta(child, alpha, beta))
                if alpha >= beta:
                    return alpha
            return alpha
        if self.max_min_dict[value] == "MIN":
            for child in current_node.children:
                beta = min(beta, self.alpha_beta(child, alpha, beta))
                if alpha >= beta:
                    return beta
            return beta

class alphabeta:
    def __init__(self, filename="alphabeta.txt"):
        self.filename = filename
        self.filename_out = "alphabeta_out.txt"
        self.remove_empty = lambda input_list: [x for x in input_list if x]
        self.graphs = self.read_file(self.filename)
        self.trees = self.build_trees(self.graphs)

    def read_file(self, filename):
        input_list = []
        with open(filename, "r") as f:
            raw = f.readlines()
        for r in raw:
            if r != "\n":
                formatted_r = r[:-1] if r[-1] == "\n" else r
                curly_bracket_idx = formatted_r.rfind("{")
                if curly_bracket_idx > 0:
                    nodes = formatted_r[:curly_bracket_idx][2:-2].split("),(")
                    edges = formatted_r[curly_bracket_idx:][2:-2].split("),(")
                    nodes = [tuple(i.split(",")) for i in nodes]
                    edges = [tuple(i.split(",")) for i in edges]
                    input_list.append((nodes, edges))
        return self.remove_empty(input_list)

    def write_file(self, filename, content):
        with open(filename, "a+") as f:
            f.write(content+"\n")
        return None

    def build_trees(self, graphs):
        trees = []
        for g in graphs:
            nodes = g[0]
            edges = g[-1]
            t = tree(nodes[0][0], dict(nodes), edges)
            trees.append(t)
        return trees

    def run_abp(self):
        for t in range(len(self.trees)):
            score = self.trees[t].alpha_beta(self.trees[t].root, None, None)
            count = self.trees[t].count
            output = "Graph {}: Score: {}; Leaf Nodes Examined: {}".format(t+1, score, count)
            self.write_file(self.filename_out, output)
            print(output)
        return None

if __name__ == "__main__":
    ab = alphabeta()
    ab.run_abp()
